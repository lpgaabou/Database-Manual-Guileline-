#!/bin/sh
set -e
# Automatically added by dh_installinit/12.10ubuntu1
if [ "$1" = "purge" ] ; then
	update-rc.d clickhouse-server remove >/dev/null
fi
# End automatically added section
# Automatically added by dh_installdebconf/12.10ubuntu1
if [ "$1" = purge ] && [ -e /usr/share/debconf/confmodule ]; then
	. /usr/share/debconf/confmodule
	db_purge
fi
# End automatically added section
